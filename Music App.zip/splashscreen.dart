import 'dart:async';

import 'package:flutter/material.dart';
import 'package:musicapp/ymusic.dart';

class Splashscreen extends StatefulWidget {
  const Splashscreen({super.key});

  @override
  State<Splashscreen> createState() => _SplashscreenState();
}

class _SplashscreenState extends State<Splashscreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Timer(

        Duration(seconds: 10),
            ()=>Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (context) => MyMusic()),)

    );
  }
  Widget build(BuildContext context) {
    return MaterialApp(

      home: Scaffold(
        backgroundColor: Colors.pink,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Center(

                child: CircleAvatar(
                  backgroundImage: AssetImage('assets/download (4).jpg'),

                  radius: 120,
                ),
              ),
              SizedBox(height: 10),

              Text(
                'BS CS',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w800,
                  color: Colors.black,
                  fontFamily: 'ItalianRegular',
                ),
              ),
              SizedBox(height: 150),


              CircularProgressIndicator(
                color: Colors.black,
              ),
              SizedBox(height: 15),
              Column(
                children: [
                  Text(
                    '2023-ag-7111',
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.w800,
                      color: Colors.black,
                      fontFamily: 'ItalianRegular',
                    ),
                  ),
                  Text(
                    'M Tayyab Ali',
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.w800,
                      color: Colors.black,
                      fontFamily: 'ItalianRegular',
                    ),
                  ),
                ],
              ),


            ],
          ),
        ),
        ),

    );
  }
}
