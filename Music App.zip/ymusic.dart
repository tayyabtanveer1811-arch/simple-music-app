import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

class MyMusic extends StatefulWidget {
  const MyMusic({super.key});

  @override
  State<MyMusic> createState() => _MyMusicState();
}

class _MyMusicState extends State<MyMusic> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(child:
        MaterialApp(

          home: Scaffold(
            backgroundColor: Colors.deepOrange,

            body: Column(
              children: [
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          final Tayyab = AudioPlayer();
                          Tayyab.play(AssetSource('note1.wav'));
                        });
                      },
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.13,
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        color: Colors.pink,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          final Tayyb = AudioPlayer();
                          Tayyb.play(AssetSource('note2.wav'));
                        });
                      },
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.13,
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        color: Colors.purpleAccent,
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          final Tayyab = AudioPlayer();
                          Tayyab.play(AssetSource('note3.wav'));
                        });
                      },
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.13,
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        color: Colors.cyan,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          final Tayyab = AudioPlayer();
                          Tayyab.play(AssetSource('note3.wav'));
                        });
                      },
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.13,
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        color: Colors.green,
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          final Tayyab = AudioPlayer();
                          Tayyab.play(AssetSource('note5.wav'));
                        });
                      },
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.13,
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        color: Colors.tealAccent,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          final Tayyab = AudioPlayer();
                          Tayyab.play(AssetSource('note6.wav'));
                        });
                      },
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.13,
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        color: Colors.pinkAccent,
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          final Tayyab = AudioPlayer();
                          Tayyab.play(AssetSource('note3.wav'));
                        });
                      },
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.13,
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        color: Colors.lightBlueAccent,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          final Tayyab = AudioPlayer();
                          Tayyab.play(AssetSource('note1.wav'));
                        });
                      },
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.13,
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        color: Colors.brown,
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          final Tayyab = AudioPlayer();
                          Tayyab.play(AssetSource('note2.wav'));
                        });
                      },
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.14,
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        color: Colors.lightGreenAccent,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          final Tayyab = AudioPlayer();
                          Tayyab.play(AssetSource('note3.wav'));
                        });
                      },
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.14,
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        color: Colors.redAccent,
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          final Tayyab = AudioPlayer();
                          Tayyab.play(AssetSource('note4.wav'));
                        });
                      },
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.13,
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        color: Colors.lightBlue,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          final Tayyab = AudioPlayer();
                          Tayyab.play(AssetSource('note4.wav'));
                        });
                      },
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.13,
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          final Tayyab = AudioPlayer();
                          Tayyab.play(AssetSource('note2.wav'));
                        });
                      },
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.13,
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        color: Colors.white54,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          final Tayyab = AudioPlayer();
                          Tayyab.play(AssetSource('note3.wav'));
                        });
                      },
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.13,
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),

              ],
            ),
          ),
        )

    );
  }
}
